# The Di-Hydro Visualization Tool — Windows EXE / Installer Build

## Best option
Run:

```bat
build_installer.bat
```

This will:
1. Remove any old broken `.venv_build`.
2. Create a fresh temporary build environment.
3. Repair/bootstrap pip with `ensurepip`.
4. Install dependencies.
5. Build `The Di-Hydro Visualization Tool.exe`.
6. Build `The_Di-Hydro_Visualization_Tool_Setup.exe` if Inno Setup 6 is installed.

## If you only need the EXE folder
Run:

```bat
build_exe.bat
```

Output:

```text
dist\The Di-Hydro Visualization Tool\The Di-Hydro Visualization Tool.exe
```

## Important
The built/installed app does not need `.venv`. The `.venv_build` folder is only temporary for compiling the EXE on the build PC.

## Requirements on the build PC
- Windows 10/11
- Python 3.10, 3.11, or 3.12
- Internet connection for pip install
- Inno Setup 6 only if you want the installer

